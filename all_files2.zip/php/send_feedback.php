                                <?php
    $feedback=$_POST['feedback'];
    mail("rclubsme@gmail.com","Rclubs: Feedback",$feedback);
    echo "Thank you for the feedback";
?>
                                
                            
                            
                            
                            