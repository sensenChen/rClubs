RPI-Clubs-and-Activities
========================

RPI Clubs and Activities is a website/mobile application where students can find when and where a specific club meets. 
