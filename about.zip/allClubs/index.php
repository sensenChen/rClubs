<?php
    session_start();
?>
<?php 
  	  include ( "../header.php" ); 
?>
<html>
    <body>
        <?php
            include 'allClubs.php';
        ?>
    </body>
</html>
                            
                            
                            
                            
                            
                            