                                <?php
    session_start();
?>       
<?php 
    include ( "../header.php" ); 
?>                                                      
<html>   
    <body>
        <center>
            <div id="bodi">
                <div class="talk">
                    <p id="descr" class="body-text">Give us your Feedback</p>
                </div>
                <div class="feedback">
                    <form method="post" action="http://rclubs.me/php/send_feedback.php">
                        <textarea name="feedback" id="feedbackbox" placeholder="Put your Feedback Here"> </textarea>
                   
                        <input type="submit" placeholder="Submit" id="submit-button"/>
                    </form>
                </div>
            </div>
        </center>   
    </body>
</html>

                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            