<html>
	<head>
	</head>
	<body>
		<p>
		<?php
			
			//require_once('../php/club_functions.php');
			//connectToDatabase();
			//echo(deleteUser(65,2));

		?>      
		</p>
	</body>       
</html>