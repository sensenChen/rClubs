                                                                                                <?php
    session_start();
?>
<?php 
  include ( "../header.php" ); 
?>
<html>  	
    <body>
        <div class="logo">
                <center>
                    <img src="../images/rClubs3.png" width="20%;">
                </center>
            </div>
        <center>
            <p class="mission_statement">
                rClubs is focused on making RPI's club information accessible to all students
            </p>
            <br/><br/>
        </center>
        
        <p class="about_text">
            <b>Never miss a club meeting again</b><br/>
            We want you to be able to stay up to date with all of your clubs. For every club that you are part of, rClubs will notify you about important meeting times and events. 
        </p>
        
        <p class="about_text">
            <b>Can't find your club?</b><br/>
            Feel free to notify us in the feedback form. After all, this site is currently a work in progress.  
        </p>
      
    </body>
</html>
                            
                            
                            
                            